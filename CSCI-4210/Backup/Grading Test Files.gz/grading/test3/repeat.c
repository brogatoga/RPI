#include <stdio.h>

int main()
{
  while ( 1 )
  {    printf( "HEY!  Get back to work.\n" );
    sleep( 5 );
  }

  return 0;
}
