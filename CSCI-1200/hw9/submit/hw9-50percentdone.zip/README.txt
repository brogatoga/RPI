HOMEWORK 9: PERFECT HASHING

NAME: Ryan Lin
EMAIL: linr2@rpi.edu


COLLABORATORS AND OTHER RESOURCES:
https://en.wikipedia.org/wiki/Hash_table
https://en.wikipedia.org/wiki/Perfect_hash_function


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT: 6 hours


SUMMARY OF RESULTS: 
Summarize your results on the provided examples.  Were you able to
construct a perfect hash function?  If not, how close did you get (how
many collisions)?  If yes, what was the smallest perfect hash you were
able to construct for the different examples?  What was your
compression ratio?  Did you make any additional test cases?



OFFSET SEARCH FOR EXTRA CREDIT:
If you implemented a search strategy instead of or in addition to the
greedy method from the paper, describe it here.



MISC. COMMENTS TO GRADER:  

None.