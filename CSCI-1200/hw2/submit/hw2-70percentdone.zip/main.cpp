/**
 * Homework 2 - Hockey Classes
 * Ryan Lin (linr2@rpi.edu)
 *
 * TODO:
 	- output and formatting
 *
**/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>

#include "game.h"
#include "action.h"
#include "game_collection.h"
#include "utils.h"
#include "state.h"


// Alias for table data structure
typedef std::vector< std::vector<std::string> > table; 


// Function prototypes
void createTeamTable(table &, GameCollection &); 
void createPlayerTable(table &, GameCollection &); 
void createCustomTable(table &, GameCollection &);

void readData(GameCollection &, std::istream &);
void writeTable(const table &, std::ofstream &); 
void error(std::string, const std::string &); 


// Main function, entrypoint of the application
int main(int argc, char *argv[])
{
	std::ofstream out_file(argv[2]);
	std::ifstream in_file(argv[1]);
	GameCollection games; 
	table teamTable, playerTable, customTable; 


	// Wrong number of command line arguments?
	if (argc != 3) {
		std::cerr << "Usage: " << argv[0] << " <input_file> <output_file>" << std::endl;
		return 1;
	}


	// Invalid output file?
	if (!out_file.good()) {
		std::cerr << "Error: unable to open output file '" << argv[2] << "'' for writing to" << std::endl;
		return 1;
	}


	// Invalid input file?
	if (!in_file.good()) {
		std::cerr << "Error: unable to open or read input file '" << argv[1] << "'" << std::endl;
		return 1;
	}


	// Read data from the input file and store it in the vector of Games
	readData(games, in_file);


	// Calculate statistics and output the results in tabular form
	createTeamTable(teamTable, games);
	createPlayerTable(playerTable, games);
	createCustomTable(customTable, games);

	writeTable(teamTable, out_file);
	out_file << std::endl;
	writeTable(playerTable, out_file);
	out_file << std::endl;
	//writeTable(customTable, out_file);


	// Exit and signal program success
	return 0; 
}


// Reads data from specified input stream and stores it in the passed vector
void readData(GameCollection &games, std::istream &in_file)
{
	State state = START;   // Current state that the parser is in
	std::string input;     // String where the next input is read into
	Game game;             // Game object to store collected data into
	Action action;         // Action object to store collected action data into
	int period = 0; 	   // Current period 
	int n;                 // Temporary integer variables 
	std::string s;         // Temporary string variables


	// Loop until there are no more inputs left to process
	while (in_file >> input) {

		// For more information on the states, refer to FSM.xls
		switch (state) {

			case START: {
				if (removeLast(input).length() > 0 && input[input.length()-1] == ',') {
					s += input; 
					state = MONTH; 
				}
				else error("At starting state, expected valid DoW but received ? instead", input); 
				break;
			}


			case MONTH: {
				if (monthToInt(input) != -1) {
					s += (" " + input); 
					state = DAY; 
				}
				else error("? is not a valid month", input);
				break;
			}


			case DAY: {
				n = atoi(removeLast(input).c_str());  
				if (n >= 1 && n <= 31 && input[input.length()-1] == ',') {
					s += (" " + input); 
					state = YEAR; 
				}
				else error("? is not a valid day", input); 
				break;
			}


			case YEAR: { 
				n = atoi(input.c_str()); 
				if (n >= 0 && n <= 3000) {
					s += (" " + input); 
					game.setDate(s); 
					s = ""; 
					state = AWAYTEAM; 
				}
				else error("? is not a valid year", input); 
				break;
			}


			case AWAYTEAM: {
				game.setAwayTeam(input);
				state = AT; 
				break;
			}


			case AT: {
				if (input == "at" || input == "vs.")
					state = HOMETEAM;
				else error("Expected 'at' or 'vs.', received ? instead", input); 
				break;
			}


			case HOMETEAM: {
				game.setHomeTeam(input);
				state = LINE_START; 
				break;
			}


			case LINE_START: {
				if (input == "PERIOD") state = PERIOD_NUMBER; 
				else if (input == "FINAL") state = FINAL; 
				else if (input == "OVERTIME") period = 4; 
				else if (validTime(input)) {
					action.setTime(input);
					state = TEAM; 
				}
				else error("Expected 'PERIOD', 'FINAL', 'OVERTIME' or valid time, received ? instead", input);
				break;
			}


			case TIME: {
				if (validTime(input)) {
					action.setTime(input);  
					state = TEAM; 
				}
				else error("? is not a valid time", input); 
				break;
			}


			case PERIOD_NUMBER: {
				n = atoi(input.c_str()); 
				if (n >= 1 && n <= 3) {
					period = n; 
					state = LINE_START; 
				}
				else error("? is not a valid period number", input); 
				break;
			}


			case TEAM: {
				action.setTeam(input);
				state = ACTION_TYPE;
				break;
			}


			case ACTION_TYPE: {
				if (input == "goal") { 
					action.setType(ACTION_GOAL); 
					state = GOAL_PLAYER;
				} 
				else if (input == "penalty") { 
					action.setType(ACTION_PENALTY);
					state = PENALTY_PLAYER;
				}
				else error("? is not a valid action type, expected 'goal' or 'penalty", input);
				break;
			}


			case GOAL_PLAYER: {
				action.setPlayer(input);
				state = LEFT_PAREN; 
				break;
			}


			case LEFT_PAREN: {
				if (input == "(") state = INSIDE_ASSIST; 
				else error("Expected '(', received ? instead", input); 
				break;
			}


			case INSIDE_ASSIST: {
				if (input == ")") {
					game.addAction(period, action); 
					action.clear(); 
					state = LINE_START; 
				}
				else {
					action.setFirstAssist(input);
					state = FIRST_ASSIST; 
				}
				break;
			}


			case FIRST_ASSIST: {
				if (input == ")") {
					game.addAction(period, action);
					action.clear(); 
					state = LINE_START; 
				}
				else {
					action.setSecondAssist(input);
					state = SECOND_ASSIST; 
				}
				break;
			}


			case SECOND_ASSIST: {
				if (input == ")") {
					game.addAction(period, action);
					action.clear(); 
					state = LINE_START; 
				}
				else error("Cannot add third assist, expected ')'", input); 
				break;
			}


			case PENALTY_PLAYER: {
				action.setPlayer(input);
				state = PENALTY_TIME; 
				break;
			}


			case PENALTY_TIME: {
				if (validTime(input)) {
					action.setPenaltyTime(input);
					state = VIOLATION;
				}
				else error("Expected valid penalty time MM:SS, received ? instead", input); 
				break;
			}


			case VIOLATION: {
				action.setViolation(input); 
				game.addAction(period, action);
				action.clear(); 
				state = LINE_START; 
				break;
			}


			case FINAL: {
				if (input == game.getAwayTeam()) state = AWAYTEAM_NAME; 
				else error("Expected away team name, received ? instead", input); 
				break;
			}


			case AWAYTEAM_NAME: {
				n = atoi(input.c_str()); 
				if (n >= 0) {
					game.setAwayScore(n);
					state = AWAYTEAM_SCORE;  
				} 
				else error("? is not a valid score for the away team", input);
				break;
			}


			case AWAYTEAM_SCORE: {
				if (input == game.getHomeTeam()) state = HOMETEAM_NAME; 
				else error("Expected home team name, received ? instead", input); 
				break;
			}


			case HOMETEAM_NAME: {
				n = atoi(input.c_str()); 
				if (n >= 0) {
					game.setHomeScore(n);
					games.add(game); 
					game.clear(); 
					state = START; 
				}
				else error("? is not a valid score for the home team", input); 
				break;
			}
		}
	}
}


// Displays an error messageo the output stream
void error(std::string message, const std::string &replace)
{
	size_t pos = message.find_first_of("?");    // using size_t instead of int to avoid warnings when compiling 
	size_t length = message.length(); 

	if (pos != std::string::npos && pos >= 0 && pos < length) {
		std::string beginning = message.substr(0, pos);
		std::string ending = message.substr((pos+1 <= length-1) ? pos+1 : length-1);
		message = beginning + replace + ending; 
	}
	
	std::cout << "Error: " << message << std::endl;
	system("read");    // wait for user key press before continuing (equivalent of "pause" on windows systems)
}