#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <vector>
#include <sstream>


// Date conversion and validation functions
std::string dowToString(int);
std::string monthToString(int);
int dowToInt(const std::string &); 
int monthToInt(const std::string &); 
bool validTime(const std::string &); 
void getTime(const std::string &, int &, int &); 


// String manipulation functions
std::string removeFirst(const std::string &); 
std::string removeLast(const std::string &); 
std::string toString(int);
std::string toString(float);
std::string toString(double); 


#endif