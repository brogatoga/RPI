// All the table functions will go here, since main.cpp
// is starting to get kinda large. 

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>
#include <algorithm>

#include "game_collection.h"
#include "utils.h"


typedef std::vector< std::vector<std::string> > table; 


// Sort: Win% DESC, Goal DESC, Team ASC
bool sortTeamTable(const std::vector<std::string> &a, const std::vector<std::string> &b)
{
	float wp1 = atof(a[4].c_str()),    // a[4] is the win percentage in 0.XX form
		  wp2 = atof(b[4].c_str()); 

	int goal1 = atoi(a[5].c_str()),
		goal2 = atoi(b[5].c_str());

	std::string name1 = a[0],	          
				name2 = b[0]; 

	if (wp1 == wp2) {
		if (goal1 == goal2)
			return name1 < name2;
		return goal1 > goal2;
	}
	return wp1 > wp2; 
}


// Sort: goals+assists DESC, penalties ASC, name ASC
bool sortPlayerTable(const std::vector<std::string> &a, const std::vector<std::string> &b)
{
	int total1 = atoi(a[2].c_str()) + atoi(a[3].c_str()),
	  	total2 = atoi(b[2].c_str()) + atoi(b[3].c_str()); 

	int penalty1 = atoi(a[4].c_str()),
		penalty2 = atoi(b[4].c_str()); 

	std::string name1 = a[0],
			    name2 = b[0]; 

	if (total1 == total2) {
		if (penalty1 == penalty2)
			return name1 < name2;
		return penalty1 < penalty2;
	} 
	return total1 > total2; 
}


// Generates the data to display the team table
// Format: Team W L T Win% Goals Pelanties
void createTeamTable(table &t, GameCollection &games)
{
	std::vector<std::string> teams = games.getTeams();
	std::vector<std::string> row;
	std::vector<int> teamData(TEAM_DATASIZE); 
	int size = teams.size(); 

	// Create the header
	std::string headerColumns[] = { "Team Name", "W", "L", "T", "Win%", "Goals", "Penalties" }; 
	for (int c = 0; c < 7; c++) 
		row.push_back(headerColumns[c]);
	t.push_back(row);
	row.clear(); 


	// Fill out the rest of the table
	for (int c = 0; c < size; c++) {
		teamData = games.getTeamDataFor(teams[c]);
		if (teamData.size() == 0)
			continue; 

		float winPercentage = (teamData[TEAM_WINS] + 0.5 * teamData[TEAM_TIES]) 
			/ (teamData[TEAM_WINS] + teamData[TEAM_LOSSES] + teamData[TEAM_TIES]); 
		std::string winPercentageString = toString(winPercentage); 

		// If win percentage is something like 0.5, then make it 0.50
		if (winPercentage == 1) {
			winPercentageString = "1.00"; 
		}
		else {
			while (winPercentageString.length() < 4)
				winPercentageString += '0'; 
		}

		row.push_back(teams[c]);
		row.push_back(toString(teamData[TEAM_WINS])); 
		row.push_back(toString(teamData[TEAM_LOSSES])); 
		row.push_back(toString(teamData[TEAM_TIES])); 
		row.push_back(winPercentageString.substr(0, 4)); 
		row.push_back(toString(teamData[TEAM_GOALS])); 
		row.push_back(toString(teamData[TEAM_PENALTIES])); 

		t.push_back(row);
		row.clear(); 
	}


	// Sort the table
	sort(t.begin()+1, t.end(), sortTeamTable); 
} 


// Generates the data to display the player table
// Format: Player Team Goals Assists Penalties
void createPlayerTable(table &t, GameCollection &games)
{
	std::vector<std::string> players = games.getPlayers();
	std::vector<std::string> row;
	std::vector<int> playerData(PLAYER_DATASIZE); 
	std::string playerTeam; 
	int size = players.size(); 


	// Create the header
	std::string headerColumns[] = { "Player Name", "Team", "Goals", "Assists", "Penalties" }; 
	for (int c = 0; c < 5; c++) 
		row.push_back(headerColumns[c]);
	t.push_back(row);
	row.clear(); 


	// Fill out the rest of the table
	for (int c = 0; c < size; c++) {
		playerData = games.getPlayerDataFor(players[c]);
		playerTeam = games.getTeamFor(players[c]); 

		if (playerData.size() == 0 || playerTeam.length() == 0)
			continue; 

		row.push_back(players[c]);
		row.push_back(playerTeam); 
		row.push_back(toString(playerData[PLAYER_GOALS])); 
		row.push_back(toString(playerData[PLAYER_ASSISTS]));
		row.push_back(toString(playerData[PLAYER_PENALTIES]));

		t.push_back(row);
		row.clear(); 
	}


	// Sort the table
	sort(t.begin()+1, t.end(), sortPlayerTable); 
}


// Generates the data to display the custom table (?)
// Format: ?
void createCustomTable(table &t, GameCollection &games)
{

}


// Formats and writes the provided table to the given output stream
void writeTable(const table &t, std::ofstream &out)
{
	// Compute the width for each column
	int rows = t.size();
	int columns = t[0].size();
	int length, maxLength;
	std::vector<int> widths(columns);


	// If no rows or columns in table, then don't print anythihng
	if (rows == 0 || columns == 0)
		return;

	// Loop through every row of each column and find the string with largest length
	for (int x = 0; x < columns; x++) {
		maxLength = 0; 
		for (int y = 0; y < rows; y++) {
			if ((length = t[y][x].length()) > maxLength)
				maxLength = length;
		}
		widths[x] = maxLength;
	}

	// Write the formatted table to the output stream
	for (int y = 0; y < rows; y++) {
		for (int x = 0; x < columns; x++) { 
			std::string s = t[y][x];

			// Numbers are right aligned, everything else is left aligned 
			if (s == "0" || s == "0.00" || atoi(s.c_str()) > 0 || atof(s.c_str()) > 0.0f)
				out << std::right; 
			else 
				out << std::left; 

			out << std::setw(widths[x]) << s << "  "; 
		}
		out << std::endl;
	}
} 