#ifndef STATE_H
#define STATE_H

// These are a list of states that the input parser could be in. 
// More information about each of these states is available in 
// main.cpp inside the readData() function. 

enum State {
	START,
	MONTH,
	DAY,
	YEAR,
	AWAYTEAM,
	AT,
	HOMETEAM,
	LINE_START,
	TIME,
	PERIOD_NUMBER,
	TEAM,
	ACTION_TYPE,
	INSIDE_ASSIST,
	GOAL_PLAYER,
	LEFT_PAREN,
	FIRST_ASSIST,
	SECOND_ASSIST,
	PENALTY_PLAYER,
	PENALTY_TIME,
	VIOLATION,
	FINAL,
	AWAYTEAM_NAME,
	AWAYTEAM_SCORE,
	HOMETEAM_NAME
};


#endif