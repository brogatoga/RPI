#include "utils.h"
#include <cstdlib>


static std::string day_strings[] = {
	"Monday", "Tuesday", "Wednesday", "Thursday",
	"Friday", "Saturday", "Sunday"
};

static std::string month_strings[] = {
	"January", "February", "March", "April",
	"May", "June", "July", "August",
	"September", "October", "November", "December"
};



// Returns day of the week in integer form (eg: "Friday" = 5)
int dowToInt(const std::string &s)
{
	for (int c = 0; c < 7; c++) {
		if (day_strings[c] == s)
			return c+1; 
	}
	return -1;
}


// Returns month in integer form (eg: "March" = 3)
int monthToInt(const std::string &s)
{
	for (int c = 0; c < 12; c++) {
		if (month_strings[c] == s)
			return c+1; 
	}
	return -1; 
}



// Returns day of the week as a word (eg: 4 = "Thursday")
std::string dowToString(int n)
{
	return (n >= 1 && n <= 7) ? day_strings[n-1] : ""; 
}



// Returns month as a word (eg: 8 = "August")
std::string monthToString(int n)
{
	return (n >= 1 && n <= 12) ? month_strings[n-1] : ""; 
}


// Returns whether a string is a valid time or not (in the format MM:SS)
bool validTime(const std::string &s)
{
	size_t colon = s.find_first_of(":"); 
	int minutes = -1; 
	int seconds = -1; 

	if (colon == std::string::npos)
		return false; 

	minutes = atoi(s.substr(0, colon).c_str()); 
	seconds = atoi(s.substr(colon+1).c_str()); 

	return (minutes >= 0 && minutes <= 20) && (seconds >= 0 && seconds <= 59)
		&& (minutes < 20 || (minutes == 20 && seconds == 0));  
}


// Parses a time-string with format MM:SS and saves the minute and second portions
void getTime(const std::string &s, int &minutes, int &seconds)
{
	if (!validTime(s)) {
		minutes = -1; 
		seconds = -1; 
		return;
	}

	size_t colon = s.find_first_of(":");
	if (colon == std::string::npos)
		return;

	minutes = atoi(s.substr(0, colon).c_str());
	seconds = atoi(s.substr(colon+1).c_str());
}


// Return a new string with the first character omitted
std::string removeFirst(const std::string &s)
{
	return (s.length() >= 2) ? 
		s.substr(1, s.length() - 1) : ""; 
}


// Return a new string with the last character omitted
std::string removeLast(const std::string &s)
{
	return (s.length() >= 2) ? 
		s.substr(0, s.length() - 1) : ""; 
}


// Returns an int in string format
std::string toString(int n)
{
	std::ostringstream stream;
	stream << n; 
	return stream.str(); 
}


// Returns a float in string format
std::string toString(double d)
{
	std::ostringstream stream;
	stream << d; 
	return stream.str(); 
}


// Returns a float in string format
std::string toString(float f)
{
	std::ostringstream stream;
	stream << f; 
	return stream.str(); 
}