HOMEWORK 1: TEXT JUSTIFICATION


NAME:  Ryan Lin
RPI ID: linr2


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclagsmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

1) stackoverflow.com/questions/9658720/ofstream-as-function-argument
2) http://www.cs.rpi.edu/academics/courses/spring14/ds/other_information.php
3) http://www.cplusplus.com/reference/string/string/


Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT: 6 hours


EXTRA CREDIT SHAPES:
Describe your new shapes, include example files of the output with
your submission, and provide the command line used to create the these
examples.  

You can create a starbox by adding "starbox" as the sixth argument, like this:  
./justify gettysburg_address.txt starbox_output.txt 50 flush_left starbox


MISC. COMMENTS TO GRADER:  

Hi. 
