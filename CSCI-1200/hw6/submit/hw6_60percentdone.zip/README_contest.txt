HOMEWORK 6: RICOCHET ROBOTS CONTEST


NAME: Ryan Lin
EMAIL: linr2@rpi.edu



COLLABORATORS AND OTHER RESOURCES:
< insert collaborators / resources >



DESCRIPTION OF ANY PERFORMANCE IMPROVEMENTS/OPTIMIZATIONS:
(please be concise!)



DESCRIBE INTERESTING NEW PUZZLES YOU CREATED:



SUMMARY OF YOUR PERFORMANCE ON ALL PUZZLES:
Correctness & approximate wall clock running time for various command
line arguments.

