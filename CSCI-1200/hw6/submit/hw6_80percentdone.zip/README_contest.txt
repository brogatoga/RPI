HOMEWORK 6: RICOCHET ROBOTS CONTEST


NAME: Ryan Lin
EMAIL: linr2@rpi.edu



COLLABORATORS AND OTHER RESOURCES:
http://www.cplusplus.com/reference/vector/vector/
http://www.cplusplus.com/reference/cstdlib/



DESCRIPTION OF ANY PERFORMANCE IMPROVEMENTS/OPTIMIZATIONS:

I didn't make any performance improvements or optimizations. Here are the running times though: 



DESCRIBE INTERESTING NEW PUZZLES YOU CREATED:

Didn't make any. 



SUMMARY OF YOUR PERFORMANCE ON ALL PUZZLES:
Correctness & approximate wall clock running time for various command
line arguments.

puzzle1.txt -visualize A -max_moves 3 => 1.713 seconds
puzzle1.txt -visualize B -max_moves 3 => 1.752 seconds
puzzle1.txt -visualize C -max_moves 3 => 1.681 seconds
puzzle1.txt -visualize A -max_moves 10 => 12.523 seconds
puzzle1.txt -max_moves 8 => 3.423 seconds
puzzle1.txt -max_moves 8 -all_solutions => 3.423 seconds
puzzle2.txt -all_solutions => 2.352 seconds
puzzle3.txt => ?
puzzle3.txt => ?
puzzle4.txt -max_moves 12 -all_solutions =>	1.712 seconds
puzzle5.txt => 1.758 seconds