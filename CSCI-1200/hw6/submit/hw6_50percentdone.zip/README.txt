HOMEWORK 6: RICOCHET ROBOTS RECURSION


NAME: Ryan Lin
EMAIL: linr2@rpi.edu 


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

http://www.cplusplus.com/reference/vector/vector/
http://www.cplusplus.com/reference/cstdlib/


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  10 hours



ANALYSIS OF PERFORMANCE OF YOUR ALGORITHM:
(order notation & concise paragraph, < 200 words)

i & j = dimensions of the board
    r = number of robots on the board
    g = number of goals
    w = number of interior walls
    m = maximum total number of moves allowed




SUMMARY OF PERFORMANCE OF YOUR PROGRAM ON THE PROVIDED PUZZLES:
Correctness & approximate wall clock running time for various command
line arguments.



MISC. COMMENTS TO GRADER:  
(optional, please be concise!)

None. 