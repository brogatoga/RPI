#include <iomanip>
#include <cstdlib>
#include <cmath>
#include "board.h"


// Constructor, initializes a new Board object
Board::Board(int r, int c)
{
    rows = r; 
    cols = c; 

    board = std::vector<std::vector<char> >(rows,std::vector<char>(cols,' '));
    vertical_walls = std::vector<std::vector<bool> >(rows,std::vector<bool>(cols+1,false));
    horizontal_walls = std::vector<std::vector<bool> >(rows+1,std::vector<bool>(cols,false));

    // Create outer walls of the grid
    for (int i = 0; i < rows; i++)
        vertical_walls[i][0] = vertical_walls[i][cols] = true;

    for (int i = 0; i < cols; i++) 
        horizontal_walls[0][i] = horizontal_walls[rows][i] = true;
}


// Query the existance of a horizontal wall
bool Board::getHorizontalWall(double r, int c) const
{
    assert (fabs((r - floor(r))-0.5) < 0.005);
    assert (r >= 0.4 && r <= rows+0.6);
    assert (c >= 1 && c <= cols);
    return horizontal_walls[floor(r)][c-1];
}


// Query the existance of a vertical wall
bool Board::getVerticalWall(int r, double c) const
{
    assert (fabs((c - floor(c))-0.5) < 0.005);
    assert (r >= 1 && r <= rows);
    assert (c >= 0.4 && c <= cols+0.6);
    return vertical_walls[r-1][floor(c)];
}


// Add an interior horizontal wall
void Board::addHorizontalWall(double r, int c)
{
    assert (fabs((r - floor(r))-0.5) < 0.005);
    assert (r >= 0 && r <= rows);
    assert (c >= 1 && c <= cols);
    assert (horizontal_walls[floor(r)][c-1] == false);
    horizontal_walls[floor(r)][c-1] = true;
}


// Add an interior vertical wall
void Board::addVerticalWall(int r, double c)
{
    assert (fabs((c - floor(c))-0.5) < 0.005);
    assert (r >= 1 && r <= rows);
    assert (c >= 0 && c <= cols);
    assert (vertical_walls[r-1][floor(c)] == false);
    vertical_walls[r-1][floor(c)] = true;
}


// Returns the value of the marker at position P
char Board::getspot(const Position &p) const
{
    assert (p.row >= 1 && p.row <= rows);
    assert (p.col >= 1 && p.col <= cols);
    return board[p.row-1][p.col-1];
}


// Sets the marker at position P to A
void Board::setspot(const Position &p, char a)
{
    assert (p.row >= 1 && p.row <=  rows);
    assert (p.col >= 1 && p.col <= cols);
    board[p.row-1][p.col-1] = a;
}


// Returns the goal at the given position
char Board::isGoal(const Position &p) const
{
    assert (p.row >= 1 && p.row <= rows);
    assert (p.col >= 1 && p.col <= cols);
   
    for (unsigned int i = 0; i < goals.size(); i++) {
        if (p == goals[i].pos)
            return goals[i].which;
    }
    return ' ';
}


// Place a new robot with marker A at position P
void Board::placeRobot(const Position &p, char a)
{
    assert (p.row >= 1 && p.row <= rows);
    assert (p.col >= 1 && p.col <= cols);
    assert (getspot(p) == ' ');
    assert (isalpha(a) && isupper(a));

    for (unsigned int i = 0; i < robots.size(); i++)
        assert (robots[i].which != a);

    robots.push_back(Robot(p, a));
    setspot(p,a);
}


// Updates the "marker" of the robot on the board
void Board::updateRobotPosition(int i, const Position& p)
{
    if (i < 0 || i >= robots.size() || robots[i].pos == p)
        return;

    int old_row = robots[i].pos.row,
        old_col = robots[i].pos.col; 

    robots[i].pos.row = p.row; 
    robots[i].pos.col = p.col; 

    setspot(Position(old_row, old_col), ' '); 
    setspot(Position(robots[i].pos.row, robots[i].pos.col), robots[i].which);
}


// Moves the robot in one of four directions and returns true if it has moved, or false if it stays put
bool Board::moveRobot(int i, char direction)
{
    if (i < 0 || i >= robots.size())
        return false;

    int rx = robots[i].pos.col,
        ry = robots[i].pos.row; 
    char id = robots[i].which; 
    direction = toupper(direction); 


    // Moving north
    if (direction == 'N' && ry > 1) {
        int destination = 1; 
        for (int c = 0; c <= ry-1; c++) {
            if (getHorizontalWall(c+0.5, rx))
                destination = c+1; 
        }
        for (int c = 0; c < robots.size(); c++) {
            if (robots[c].which != id && robots[c].pos.col == rx
                && robots[c].pos.row < ry && robots[c].pos.row >= destination)
                destination = robots[c].pos.row + 1; 
        }
        updateRobotPosition(i, Position(destination, rx));
    }

    // Moving south 
    else if (direction == 'S' && ry < rows) {
        int destination = rows;
        for (int c = rows; c >= ry+1; c--) {
            if (getHorizontalWall(c-0.5, rx))
                destination = c-1; 
        }
        for (int c = 0; c < robots.size(); c++) {
            if (robots[c].which != id && robots[c].pos.col == rx
                && robots[c].pos.row > ry && robots[c].pos.row <= destination)
                destination = robots[c].pos.row - 1;  
        }
        updateRobotPosition(i, Position(destination, rx));  
    }

    // Moving west
    else if (direction == 'W' && rx > 1) {
        int destination = 1; 
        for (int c = 0; c <= rx-1; c++) {
            if (getVerticalWall(ry, c+0.5))
                destination = c+1;
        }
        for (int c = 0; c < robots.size(); c++) {
            if (robots[c].which != id && robots[c].pos.row == ry
                && robots[c].pos.col < rx && robots[c].pos.col >= destination)
                destination = robots[c].pos.col + 1; 
        }
        updateRobotPosition(i, Position(ry, destination)); 
    }

    // Moving east
    else if (direction == 'E' && rx < cols) {
        int destination = cols; 
        for (int c = cols; c >= rx+1; c--) {
            if (getVerticalWall(ry, c-0.5))
                destination = c-1;
        }
        for (int c = 0; c < robots.size(); c++) {
            if (robots[c].which != id && robots[c].pos.row == ry
                && robots[c].pos.col > rx && robots[c].pos.col <= destination)
                destination = robots[c].pos.col - 1; 
        }
        updateRobotPosition(i, Position(ry, destination)); 
    }

    // Invalid direction
    else {
        return false; 
    }

    // If robot's position has changed, then return true, otherwise return false
    return robots[i].pos != Position(ry, rx); 
}


// Returns the robot ID (index in the vector) given its alphabetical marker
int Board::getRIDFromMarker(char marker) const
{
    for (int c = 0; c < robots.size(); c++) {
        if (robots[c].which == marker)
            return c; 
    }
    return -1; 
}


// Adds a new goal to the board 
void Board::addGoal(const std::string &gr, const Position &p)
{
    // check that input data is reasonable
    assert (p.row >= 1 && p.row <= rows);
    assert (p.col >= 1 && p.col <= cols);

    char goal_robot;
    if (gr == "any") {
        goal_robot = '?';
    } else {
        assert (gr.size() == 1);
        goal_robot = gr[0];
        assert (isalpha(goal_robot) && isupper(goal_robot));
    }

    // verify that a robot of this name exists for this puzzle
    if (goal_robot != '?') {
        int robot_exists = false;
        for (unsigned int i = 0; i < robots.size(); i++) {
            if (getRobot(i) == goal_robot) 
                robot_exists = true;
        }
        assert (robot_exists);
    }
    
    // make sure we don't already have a robot at that location
    assert (isGoal(p) == ' ');

    // add this goal label and position to the vector of goals
    goals.push_back(Goal(p,goal_robot));
}


// Given a direction (N,S,W,E) outputs the full name of the direction
std::string Board::directionToString(char direction) const
{
    switch (direction) {
        case 'N': return "north";
        case 'S': return "south";
        case 'W': return "west";
        case 'E': return "east"; 
    }
    return "";
}


// Prints the board
void Board::print() const
{
    // print the column headings
    std::cout << " ";
    for (int j = 1; j <= cols; j++) {
        std::cout << std::setw(5) << j;
    }
    std::cout << "\n";
    
    // for each row
    for (int i = 0; i <= rows; i++) {

        // don't print row 0 (it doesnt exist, the first real row is row 1)
        if (i > 0) {
            
            // Note that each grid rows is printed as 3 rows of text, plus
            // the separator.  The first and third rows are blank except for
            // vertical walls.  The middle row has the row heading, the
            // robot positions, and the goals.  Robots are always uppercase,
            // goals are always lowercase (or '?' for any).
            std::string first = "  ";
            std::string middle;
            for (int j = 0; j <= cols; j++) {

                if (j > 0) { 
                    // determine if a robot is current located in this cell
                    // and/or if this is the goal
                    Position p(i,j);
                    char c = getspot(p);
                    char g = isGoal(p);
                    if (g != '?') g = tolower(g);
                    first += "    ";
                    middle += " "; 
                    middle += c; 
                    middle += g; 
                    middle += " ";
                }

                // the vertical walls
                if (getVerticalWall(i,j+0.5)) {
                    first += "|";
                    middle += "|";
                } else {
                    first += " ";
                    middle += " ";
                }
            }

            // output the three rows
            std::cout << first << std::endl;
            std::cout << std::setw(2) << i << middle << std::endl;
            std::cout << first << std::endl;
        }

        // print the horizontal walls between rows
        std::cout << "  +";
        for (double j = 1; j <= cols; j++) {
            (getHorizontalWall(i+0.5,j)) ? std::cout << "----" : std::cout << "    ";
            std::cout << "+";
        }
        std::cout << "\n";
    }
}


// Prints the vision map for a specified robot
void Board::printVisionMap(char marker) const
{
    int rid;
    int width, height; 

    if ((rid = getRIDFromMarker(marker)) < 0)
        return;

    width = robots[rid].vision.getWidth();
    height = robots[rid].vision.getHeight(); 

    if (robots[rid].vision.empty()) {
        std::cout << "No vision map for " << marker << " has been generated yet" << std::endl;
        return;
    }

    std::cout << "Reachable by robot " << marker << ":" << std::endl;
    for (int r = 1; r <= height; r++) {
        for (int c = 1; c <= width; c++)
            std::cout << "  " << robots[rid].vision.get(Position(r, c)).marker;
        std::cout << std::endl;
    }
}


// Prints the solution(s) for the board
// TODO: print all_solutions
// TODO: multiple goals (also maybe there is a certain order we have to move the robots in, in order to get all goals)
// TODO: what if target is not in vision map, so we need to move another robot and regenerate vision map?
void Board::printSolution(int max_moves, bool all_solutions)
{
    if (all_solutions) {
        // TBD later
    }

    else {
        char robot = goals[0].which;
        int rid = getRIDFromMarker(robot);
        int shortest_path = -1; 
        Position destination = goals[0].pos;

        // If this goal can be occupied by any robot, then generate vision maps for all robots
        if (robot == '?') {
            for (int c = 0; c < robots.size(); c++) {
                generateVisionMap(c, max_moves);

                // Find the robot with the shortest path to the destination, and use it to calculate the solution
                int path_length = robots[c].vision.get(destination).steps.size();
                if (shortest_path == -1 || path_length < shortest_path) {
                    shortest_path = path_length;
                    rid = c; 
                    robot = robots[c].which;
                }
            }
        }

        // Otherwise, just generate the vision map for the one robot that is supposed to occupy that goal
        else {
            generateVisionMap(rid, max_moves);
        }

        const VisionEntry solution = robots[rid].vision.get(destination);

        if (solution.steps.size() == 0) {
            if (max_moves > 0) std::cout << "no solutions with " << max_moves << " or fewer moves" << std::endl;
            else std::cout << "no solutions";
            return;
        }

        print();
        for (int c = 0; c < solution.steps.size(); c++) {
            std::cout << "robot " << robots[solution.steps[c].id].which << " moves " << directionToString(solution.steps[c].direction) << std::endl;
            moveRobot(solution.steps[c].id, solution.steps[c].direction);
            print();  
        }
        std::cout << "All goals are satisfied after " << solution.steps.size() << " moves" << std::endl;
    }
}


// Generates a new vision map for the specified robot
void Board::generateVisionMap(int rid, int max_moves)
{
    robots[rid].vision.clear(); 
    robots[rid].vision = VisionMap(cols, rows); 
    robots[rid].vision.set(robots[rid].pos, VisionEntry('0')); 

    std::vector<std::vector<char > > current_board = board; 
    visualize(rid, max_moves);
    board = current_board; 
}


// Recursive helper function to help calculate the vision map for generateVisionMap() function
// TODO: handle case where max_moves = -1
// TODO: fix bug where marker+10 = ':'
// TODO: make it so that multiple solutions can be added for each target
// TODO: add the option to loop/recurse until the target position is found
// TODO: make the algorithm more efficient (it tends to slow down exponentially when max_moves >= 10 for robots == 3)
void Board::visualize(int rid, int max_moves, int move_number, int last_rid, char last_dir, VisionEntry path)
{
    // If we have reached the maximum number of moves, then stop processing
    if (max_moves >= 0 && move_number > max_moves)
        return;

    char directions[] = "NSWE"; 
    const int directions_size = 4; 

    for (int r = 0; r < robots.size(); r++) {
        for (int d = 0; d < directions_size; d++) {
            Position original_position = robots[r].pos; 
            path.steps.push_back(RobotMove(r, directions[d])); 

            // Try to move the targeted robot in one of the four directions
            if (moveRobot(r, directions[d])) {

                /*
                // Don't move in the opposite direction that this robot previously moved in
                if (last_rid == r && last_dir != ' ') {
                    if ((directions[d] == 'N' && last_dir == 'S') ||
                        (directions[d] == 'S' && last_dir == 'N') ||
                        (directions[d] == 'W' && last_dir == 'E') ||
                        (directions[d] == 'E' && last_dir == 'W'))
                        continue;
                }
                */

                // If the specified robot moved to this location, then mark it on its vision graph
                if (r == rid) {
                    char marker = '.';     // Current marker at the given location
                    if (!robots[rid].vision.empty())
                        marker = robots[rid].vision.get(robots[rid].pos).marker; 

                    // But only mark it if the location is either undiscovered, or we found a shorter path
                    if (marker == '.' || marker > ('0' + move_number)) {
                        path.marker = ('0' + move_number); 
                        robots[rid].vision.set(robots[rid].pos, VisionEntry(path));
                    } 
                }
                visualize(rid, max_moves, move_number+1, r, directions[d], path); 
            }

            robots[r].pos = original_position; 
            path.steps.pop_back();
        }
    }
} 