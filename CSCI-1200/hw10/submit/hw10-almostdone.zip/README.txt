HOMEWORK 10: MULTIPLE INHERITANCE & EXCEPTIONS

NAME: Ryan Lin
EMAIL: linr2@rpi.edu


COLLABORATORS AND OTHER RESOURCES:
ALAC tutoring -- Tuesday @ SAGE
http://www.cprogramming.com/tutorial/virtual_inheritance.html
https://en.wikipedia.org/wiki/Virtual_inheritance


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT: 5 hours


MISC. COMMENTS TO GRADER:  

For the sake of readability I put the function bodies for constructors in the 
class declaration. Please don't take points off for that. The code would be 
a lot harder to follow if I put all 17 constructors in the .cpp file instead.