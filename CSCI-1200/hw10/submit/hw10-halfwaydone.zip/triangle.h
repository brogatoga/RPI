#ifndef TRIANGLE_H
#define TRIANGLE_H 

// ------------------------------------------------------------------------------------

class Triangle : public Polygon
{
public:
	Triangle(const std::string& _name, const std::vector<Point>& _points) : Polygon(_name, _points) {
		if (points.size() != 3) throw -1; 
	}
	virtual std::vector<double> GetSides() const; 
	virtual std::vector<double> GetAngles() const; 
}; 

// ------------------------------------------------------------------------------------

class RightTriangle : virtual public Triangle
{
public:
	RightTriangle(const std::string& _name, const std::vector<Point>& _points) : Triangle(_name, _points)  {
	}
	bool HasARightAngle() const { return true; }
}; 

// ------------------------------------------------------------------------------------

class IsoscelesTriangle : virtual public Triangle
{
public:
	IsoscelesTriangle(const std::string& _name, const std::vector<Point>& _points) : Triangle(_name, _points) {
		// check 2 equal sides
	}
}; 

// ------------------------------------------------------------------------------------

class ObtuseTriangle : virtual public Triangle
{
public:
	ObtuseTriangle(const std::string& _name, const std::vector<Point>& _points) : Triangle(_name, _points) {
		// check obtuse angle
	}
	bool HasAnObtuseAngle() const { return false; }
}; 

// ------------------------------------------------------------------------------------

class EquilateralTriangle : public IsoscelesTriangle
{
public:
	EquilateralTriangle(const std::string& _name, const std::vector<Point>& _points)
	 : IsoscelesTriangle(_name, _points), Triangle(_name, _points) {
		// check obtuse angle
	}
	bool HasAllEqualSides() const { return false; }
	bool HasAllEqualAngles() const { return false; }
	bool HasARightAngle() const { return false; }
	bool HasAnAcuteAngle() const { return true; }
}; 

// ------------------------------------------------------------------------------------

class IsoscelesObtuseTriangle : public IsoscelesTriangle, public ObtuseTriangle
{
public:
	IsoscelesObtuseTriangle(const std::string& _name, const std::vector<Point>& _points) 
		: IsoscelesTriangle(_name, _points), ObtuseTriangle(_name, _points), Triangle(_name, _points) {
		// check obtuse angle
	}
	bool HasAnObtuseAngle() const { return true; }
}; 

// ------------------------------------------------------------------------------------

class IsoscelesRightTriangle : public IsoscelesTriangle, public RightTriangle
{
public:
	IsoscelesRightTriangle(const std::string& _name, const std::vector<Point>& _points) 
		: IsoscelesTriangle(_name, _points), RightTriangle(_name, _points), Triangle(_name, _points) {
		// check obtuse angle
	}
	bool HasARightAngle() const { return true; }
}; 

// ------------------------------------------------------------------------------------

#endif