#ifndef QUADRILATERAL_H
#define QUADRILATERAL_H

// ------------------------------------------------------------------------------------

class Quadrilateral : public Polygon
{
public:
	Quadrilateral(const std::string& _name, const std::vector<Point>& _points) : Polygon(_name, _points) {
		if (points.size() != 4) throw -1; 
	}
	virtual std::vector<double> GetSides() const;
	virtual std::vector<double> GetAngles() const;
}; 

// ------------------------------------------------------------------------------------

class Kite : virtual public Quadrilateral
{
public:
	Kite(const std::string& _name, const std::vector<Point>& _points) : Quadrilateral(_name, _points) {
		// check
	}
}; 

// ------------------------------------------------------------------------------------

class Arrow : public Quadrilateral
{
public:
	Arrow(const std::string& _name, const std::vector<Point>& _points) : Quadrilateral(_name, _points) {
		// check
	}
}; 

// ------------------------------------------------------------------------------------

class Trapezoid : virtual public Quadrilateral
{
public:
	Trapezoid(const std::string& _name, const std::vector<Point>& _points) : Quadrilateral(_name, _points) {
		// check
	}
}; 

// ------------------------------------------------------------------------------------

class Parallelogram : virtual public Trapezoid
{
public:
	Parallelogram(const std::string& _name, const std::vector<Point>& _points)
	 : Trapezoid(_name, _points), Quadrilateral(_name, _points) {
		// 
	}
}; 

// ------------------------------------------------------------------------------------

class Rhombus : public Kite, virtual public Parallelogram
{
public:
	Rhombus(const std::string& _name, const std::vector<Point>& _points)
	 : Kite(_name, _points), Parallelogram(_name, _points), Trapezoid(_name, _points), Quadrilateral(_name, _points) {
		// check
	}
}; 

// ------------------------------------------------------------------------------------

class IsoscelesTrapezoid : virtual public Trapezoid
{
public:
	IsoscelesTrapezoid(const std::string& _name, const std::vector<Point>& _points)
	 : Trapezoid(_name, _points), Quadrilateral(_name, _points){
		// check
	}
}; 

// ------------------------------------------------------------------------------------

class Rectangle : virtual public Parallelogram, public IsoscelesTrapezoid
{
public:
	Rectangle(const std::string& _name, const std::vector<Point>& _points) 
		: Parallelogram(_name, _points), IsoscelesTrapezoid(_name, _points), Trapezoid(_name, _points), Quadrilateral(_name, _points) {
		// check
	}
	bool HasAllEqualAngles() const { return false; }
	bool HasARightAngle() const { return true; }
	bool HasAnObtuseAngle() const { return false; }
	bool HasAnAcuteAngle() const { return false; }
}; 

// ------------------------------------------------------------------------------------

class Square : public Rhombus, public Rectangle
{
public:
	Square(const std::string& _name, const std::vector<Point>& _points) 
		: Rhombus(_name, _points), Rectangle(_name, _points), Parallelogram(_name, _points), Trapezoid(_name, _points), Quadrilateral(_name, _points) {
		// check
	}
	bool HasAllEqualSides() const { return false; }
}; 

// ------------------------------------------------------------------------------------

#endif