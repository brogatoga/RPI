HOMEWORK 8: FRIENDLY RECURSION

NAME: Ryan Lin
EMAIL: linr2@rpi.edu

TODO:
	- pass_messages functionality
	- custom test cases
	- telephone game (extra credit)


COLLABORATORS AND OTHER RESOURCES:
http://www.cplusplus.com/reference/list/list/
http://www.cplusplus.com/reference/vector/vector/


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT: 6 hours


NETWORK COMPLEXITY
Analysis of the maximum number of people at a party with chain
length n, if each person has at most k friends.

ANSWER: The maximum number of people is equal to SUM(j=0, n, k^j).
EXPLANATION: At first there is only 1 person, which is the host. However, the host has at most k friends, we will call these
	first-order friends. Then these k first-order friends will also have at most k friends each for a total of k^2 second-order
	friends. Then these k^2 second-order friends will also have k friends each, for a total of k^3 third-order friends. And so
	on, and so forth. Then the total number of friends is equal to 1 + k^2 + k^3 + ... + k^n, which is equivalent
	to SUM(j=0, n, k^j), which means that we sum the values of k^j, where 0 <= j <= n. 


YOUR NEW TEST CASES
Submitted as an input file named my_input.txt.  Briefly describe how
this test exercises the corner cases of your implementation.  Why is
this test case interesting and/or challenging?


EXTRA CREDIT
Describe your (optional) implementation of the telephone game.


MISC. COMMENTS TO GRADER:  
None. 