#include "message.h"
#include "person.h"


// 
bool Message::pass_message(Person* person)
{
	return true; 
}