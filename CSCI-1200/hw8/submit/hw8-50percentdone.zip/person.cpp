#include "person.h"
#include "message.h"


// Returns whether this person is friends with another person
bool Person::is_friend(Person* person) const
{

}


// Returns whether this person exists in the friend list or not
bool Person::friend_exists(Person* person) const
{

}


// Returns whether this person has a particular message string or not
bool Person::message_exists(const std::string& message) const
{

}


// Adds a new friend to this person's friend list
bool Person::add_friend(Person *person)
{

}


// Removes a friend from this person's friend list 
bool Person::remove_friend(Person* person)
{

}


// Adds a new message to this person's message list
bool Person::add_message(Message *message)
{

}


// Removes a specific message from this person's message list
bool Person::remove_message(Message *message)
{

}