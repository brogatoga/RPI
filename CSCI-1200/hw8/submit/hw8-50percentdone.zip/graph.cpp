#include "graph.h"
#include "person.h"
#include "message.h"


// Constructor, properly initializes a new Graph object
Graph::Graph()
{

}


// Destructor, frees all allocated memory and other cleanup routines
Graph::~Graph()
{
	for (int c = 0; c < m_people.size(); c++) {
		if (m_people[c] != NULL)
			delete m_people[c]; 
	}

	for (int c = 0; c < m_messages.size(); c++) {
		if (m_messages[c] != NULL)
			delete m_messages[c];
	}
}


// Returns pointer to person with the given name, or NULL if he doesn't exist
Person* Graph::find_person(const std::string &name) const
{
	for (int c = 0; c < m_people.size(); c++) {
		if (m_people[c] != NULL && m_people[c]->get_name() == name)
			return m_people[c]; 
	}
	return NULL; 
}


// Adds a new person to the graph and returns success status
bool Graph::add_person(const std::string& person_name)
{
	if (find_person(person_name) != NULL || person_name.length() == 0)
		return false; 
	m_people.push_back(new Person(person_name)); 
	return true; 
}


// Removes a person with given name from the graph and returns success status
bool Graph::remove_person(const std::string& person_name)
{
	Person* p = find_person(person_name); 
	if (p == NULL || person_name.length() == 0)
		return false; 

	// TBD
}


// Adds a new friendship between two people in the graph
bool Graph::add_friendship(const std::string& person_name1, const std::string& person_name2)
{
	Person *p1 = find_person(person_name1), 
		   *p2 = find_person(person_name2); 
	return (p1 != NULL && p2 != NULL) ? p1->add_friend(p2) : false;
}


// Removes a friendship between two people in the graph
bool Graph::remove_friendship(const std::string& person_name1, const std::string& person_name2)
{
	Person *p1 = find_person(person_name1),
		   *p2 = find_person(person_name2); 
	return (p1 != NULL && p2 != NULL) ? p1->remove_friend(p2) : false; 	
}


// Adds a new message to a specific person's message list in the graph
bool Graph::add_message(const std::string& person_name, const std::string& message)
{
	Person* p = find_person(person_name); 
	if (p != NULL) {
		Message* m = new Message(message, p);
		return p->add_message(m);
	}
	return false; 
}


// TBD later
void Graph::pass_messages(MTRand &mtrand)
{
	// TBD
}


// Prints out a visualization of the entire graph
void Graph::print(std::ostream &ostr) const
{
	std::vector<Person*> people_ordered;

	for (int c = 0; c < m_people.size(); c++) {
		if (m_people[c] != NULL)
			people_ordered.push_back(m_people[c]);
	}
	std::sort(people_ordered.begin(), people_ordered.end(), friend_sorter);

	for (std::vector<Person*>::iterator it = people_ordered.begin(); it != people_ordered.end(); it++) {
		const std::list<Person*>& p = (*it)->get_friends();
		const std::list<Message*>& m = (*it)->get_messages();

		ostr << (*it)->get_name() << std::endl;
		ostr << "friends:";

		for (std::list<Person*>::const_iterator p_it = p.begin(); p_it != p.end(); p_it++)
			ostr << " " << (*p_it)->get_name(); 

		ostr << std::endl;
		ostr << "messages:";

		for (std::list<Message*>::const_iterator m_it = m.begin(); m_it != m.end(); m_it++)
			ostr << " " << (*m_it)->get_message();  
		ostr << std::endl;
	}
	ostr << std::endl;
}


// Prints out the names of people invited to a party within N range of the particular person who is hosting the party
bool Graph::print_invite_list(std::ostream &ostr, const std::string &name, int n) const
{
	Person* me = find_person(name);
	if (n < 0 || me == NULL)
		return false;

	ostr << "Invite list of " << name << " " << n << ":";
	print_invite_list_helper(ostr, n, 0, me);
	ostr << std::endl;
	return true;
}


// Recursive helper function for print_invite_list() function
void Graph::print_invite_list_helper(std::ostream& ostr, int n, int current, Person* p) const
{
	if (current >= n || p == NULL)
		return; 

	std::list<Person*> friends = p->get_friends(); 
	std::list<Person*>::iterator it; 

	for (it = friends.begin(); it != friends.end(); it++) {
		ostr << " " << (*it)->get_name();  
		print_invite_list_helper(ostr, n, current+1, *it);
	}
}