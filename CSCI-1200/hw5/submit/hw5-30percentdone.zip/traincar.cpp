// =======================================================================
//
// IMPORTANT NOTE: You should edit this file
//
//    This file provides the code for ASCII art printing of trains.
//    You should implement all of the functions prototyped in
//    "traincar_prototypes.h" in this file.
//
// =======================================================================


#include <iostream>
#include <iomanip>
#include <string>
#include <cassert>
#include "traincar.h"


// =======================================================================
// =======================================================================

// This helper function checks that the forward and backward pointers
// in a doubly-linked structure are correctly and consistently assigned.
void SanityCheck(TrainCar* train) {
  // an empty train is valid
  if (train == NULL) return;
  assert (train->prev == NULL);
  TrainCar *tmp = train;
  while (tmp->next != NULL) {
    // the next train better point back to me
    assert (tmp->next->prev == tmp);
    tmp = tmp->next;
  }
}


// This helper function prints one of the 5 rows of the TrainCar ASCII art
void PrintHelper(TrainCar* t, int which_row) {
  if (t == NULL) {
    // end of the line
    std::cout << std::endl;
    return;
  }

  if (which_row == 0) {
    // the top row only contains "smoke" for engine traincars
    if (t->isEngine()) {
      std::cout << "     ~~~~";
    } else {
      std::cout << "         ";
    }
  } else if (which_row == 1) {
    // the 2nd row only contains the smoke stack for engine traincars
    if (t->isEngine()) {
      std::cout << "    ||   ";
    } else {
      std::cout << "         ";
    }
  } else if (which_row == 2) {
    // the 3rd row contains the ID for each traincar
    // (and engine traincars are shaped a little differently)
    if (t->isEngine()) {
      std::cout << "   " << std::setw(6) << std::setfill('-') << t->getID();
    } else {
      std::cout << std::setw(9) << std::setfill('-') << t->getID();
    }
    std::cout << std::setfill(' ');
  } else if (which_row == 3) {
    // the 4th row is different for each TrainCar type
    if (t->isEngine()) {
      std::cout << " / ENGINE";
    } else if (t->isFreightCar()) {
      // freight cars display their weight
      std::cout << "|" << std::setw(5) << t->getWeight() << "  |";
    } else if (t->isPassengerCar()) {
      // passenger cars are simple empty boxes
      std::cout << "|       |";
    } else if (t->isDiningCar()) {
      std::cout << "|  dine |";
    } else {
      assert (t->isSleepingCar());
      std::cout << "| sleep |";
    }
  } else if (which_row == 4) {
    // final row is the same for all cars, just draw the wheels
    std::cout << "-oo---oo-";
  }

  // between cars display the '+' link symbol on the 5th row 
  // (only if there is a next car)
  if (t->next != NULL) {
    if (which_row == 4) {
      std::cout << " + ";
    } else {
      std::cout << "   ";
    }
  }

  // recurse to print the rest of the row
  PrintHelper(t->next, which_row);
}


// Pushes a new car onto the back of the train
void PushBack(TrainCar*& train, TrainCar* car)
{
  if (train == NULL) {
    train = car; 
    train->prev = train->next = NULL; 
    return;
  }

  TrainCar* last = train; 
  while (last->next != NULL)
    last = last->next; 

  last->next = car; 
  last->next->next = NULL; 
  last->next->prev = last; 
}



// Counts the weight, total engines (and different types of cars too) of a train overall
void CountEnginesAndTotalWeight(const TrainCar* train, int& total_weight, int& num_engines, int& num_freight_cars, 
  int& num_passenger_cars, int &num_dining_cars, int &num_sleeping_cars)
{
  const TrainCar* car = train; 
  int tw = 0, ne = 0, nf = 0, np = 0, nd = 0, ns = 0; 

  while (car != NULL) {
    if (car->isEngine()) ne++;
    else if (car->isFreightCar()) nf++; 
    else if (car->isPassengerCar()) np++; 
    else if (car->isDiningCar()) nd++; 
    else if (car->isSleepingCar()) ns++; 
    tw += car->getWeight(); 
    car = car->next; 
  }

  total_weight = tw, num_engines = ne, num_freight_cars = nf, 
  num_passenger_cars = np, num_dining_cars = nd, num_sleeping_cars = ns; 
}


// Deletes all cars on a train and deallocates all allocated memory
void DeleteAllCars(TrainCar*& train)
{
  if (train == NULL)
    return;

  TrainCar* car = train; 
  TrainCar* next = NULL; 

  while (car != NULL) {
    next = car->next; 
    delete car; 
    car = next; 
  }
}


// Calculates the speed of the given train on a 2% incline
float CalculateSpeed(const TrainCar* train)
{
  float result; 
  int horsepower = 0; 
  int weight = 0; 

  for (const TrainCar* car = train; car != NULL; car = car->next) {
    if (car->isEngine())
      horsepower += 3000;  
    weight += car->getWeight(); 
  }

  // need to calculate it in multiple steps, or else the float will overflow...
  result = float(horsepower * 550 / 40); 
  result *= 3600; 
  result /= (5280 * weight); 

  return result; 
}


// Calculates and returns the average distance to the dining car
float AverageDistanceToDiningCar(const TrainCar* train)
{
  int total_distance = 0; 
  int num_passenger_cars = 0; 
  int passenger_index = -1, dining_index = -1; 
  int counter = 0; 

  for (const TrainCar* a = train; a != NULL; a = a->next) {

    // If this is a passenger car, then calculate the distance to nearest dining car and record it
    if (a->isPassengerCar()) {
      num_passenger_cars++; 
      passenger_index = counter;
      int closest_distance = -1, distance = 0; 

      // Search backward to find dining car
      int back_counter = counter; 
      for (const TrainCar* b = a; b != train && b != NULL && !b->isEngine(); b = b->prev) {
         if (b->isDiningCar()) {
            distance = passenger_index - back_counter; 
            if (closest_distance > distance || closest_distance == -1)
              closest_distance = distance; 
         }
         back_counter--; 
      }

      // Search forward to find dining car
      int forward_counter = counter; 
      for (const TrainCar* b = a; b != NULL && !b->isEngine(); b = b->next) {
        if (b->isDiningCar()) {
            distance = forward_counter - passenger_index; 
            if (closest_distance > distance || closest_distance == -1)
              closest_distance = distance; 
         }
         forward_counter++; 
      }

      // If dining car not found or blocked by engine, then return error code to signal infinity
      if (closest_distance <= 0) 
        return -1; 

      // Otherwise, add it to the total distance
      else 
        total_distance += closest_distance; 
    }
    counter++; 
  }
  return (total_distance > 0 && num_passenger_cars > 0) ? (float)total_distance / num_passenger_cars : -1; 
}


// Calculates and returns the closest distance between an engine and any sleeping car
int ClosestEngineToSleeperCar(const TrainCar* train)
{
  int closest_distance = -1; 
  int engine_location = -1, sleeper_location = -1;
  int counter = 0; 

  for (const TrainCar* car = train; car != NULL; car = car->next) {
    if (car->isEngine())
      engine_location = counter; 
    else if (car->isSleepingCar())
      sleeper_location = counter; 

    if (engine_location >= 0 && sleeper_location >= 0 && engine_location != sleeper_location) {
      int distance = (engine_location > sleeper_location) ? engine_location - sleeper_location : sleeper_location - engine_location; 
      if (distance < closest_distance || closest_distance == -1)
        closest_distance = distance; 
    }
    counter++; 
  }
  return closest_distance; 
}


// Prints the details and summary statistics of a train
void PrintTrain(TrainCar* train) {
  
  if (train == NULL) { 
    std::cout << "PrintTrain: empty train!" << std::endl; 
    return; 
  }

  // Print each of the 5 rows of the TrainCar ASCII art
  PrintHelper(train, 0);
  PrintHelper(train, 1);
  PrintHelper(train, 2);
  PrintHelper(train, 3);
  PrintHelper(train, 4);

  int total_weight = 0;
  int num_engines = 0;
  int num_freight_cars = 0;
  int num_passenger_cars = 0;
  int num_dining_cars = 0;
  int num_sleeping_cars = 0;

  CountEnginesAndTotalWeight(train, total_weight, num_engines, num_freight_cars, num_passenger_cars, 
    num_dining_cars, num_sleeping_cars);
  int total_cars = num_engines+num_freight_cars+num_passenger_cars+num_dining_cars+num_sleeping_cars;

  float speed = CalculateSpeed(train);
  std::cout << "#cars = " << total_cars;
  std::cout << ", total weight = " << total_weight;
  std::cout << ", speed on 2% incline = " << std::setprecision(1) << std::fixed << speed;

  // If there is at least one passenger car, print the average
  // distance to dining car statistic
  if (num_passenger_cars > 0) {
    float dist_to_dining = AverageDistanceToDiningCar(train);
    if (dist_to_dining < 0) {
      // If one or more passenger cars are blocked from accessing the
      // dining car (by an engine car) then the distance is infinity!
      std::cout << ", avg distance to dining = inf";
    } else {
      std::cout << ", avg distance to dining = " << std::setprecision(1) << std::fixed << dist_to_dining;
    }
  }

  // If there is at least one sleeping car, print the closest engine
  // to sleeper car statistic
  if (num_sleeping_cars > 0) {
    int closest_engine_to_sleeper = ClosestEngineToSleeperCar(train);
    std::cout << ", closest engine to sleeper = " << closest_engine_to_sleeper;
  }

  std::cout << std::endl;
}


// =======================================================================
// =======================================================================

